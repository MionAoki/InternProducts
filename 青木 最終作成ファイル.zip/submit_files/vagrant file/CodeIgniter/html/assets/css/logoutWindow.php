<?php header('Content-Type: text/css; charset=utf-8'); ?>

.modalBg .logoutWindow
{
        position      : absolute;
        width:300px;
        height:150px;
        top: 400px; left: 50%;
        padding: 40px;
        padding-bottom: 20px;
        transform: translate(-50%, -50%);
        z-index: 11;
        min-width     : 200px;
        min-height    : 150px;
        background    : rgba(255,255,255,0.9);
        text-align    : center;
}

<?php header('Content-Type: text/css; charset=utf-8'); ?>

.main{
background: #f0f8ff;
text-align: center;
width:600px;
margin: 20px auto auto auto;
padding-bottom: 30px;
}

.form-group{
margin: 10px 100px;
}



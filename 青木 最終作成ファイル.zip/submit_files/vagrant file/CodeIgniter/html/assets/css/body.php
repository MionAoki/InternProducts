<?php header('Content-Type: text/css; charset=utf-8'); ?>

body{
background-image:url("http://192.168.33.10/assets/img/mydog.jpg");
-webkit-backdrop-filter: blur(4px);
backdrop-filter: blur(4px);
background-size:cover;
background-attachment: fixed;
}


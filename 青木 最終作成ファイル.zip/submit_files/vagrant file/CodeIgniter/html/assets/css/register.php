<?php header('Content-Type: text/css; charset=utf-8'); ?>
.main{
	background: #cce7ff;
	text-align: center;
	width:600px;
	margin: 20px auto auto auto;
	padding-bottom:30px;
}

<?php header('Content-Type: text/css; charset=utf-8'); ?>

.noset{color: #808080;}


<?php header('Content-Type: text/css; charset=utf-8'); ?>

input[type=checkbox]{display: none;}
.checkbox label{margin:0px 5px 10px 5px;}

